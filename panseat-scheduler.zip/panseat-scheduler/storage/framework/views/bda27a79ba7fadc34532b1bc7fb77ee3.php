<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex items-center justify-center min-h-screen bg-cream">
        <div class="flex w-10/12 max-w-4xl overflow-hidden bg-green rounded-lg shadow-lg">
            <!-- Left Design Section -->
            <div class="w-1/2 bg-light-green flex items-center justify-center p-10">
                <div class="relative flex flex-col items-center">
                    <div class="absolute bg-orange w-48 h-48 rounded-lg"></div>
                    <div class="absolute bg-yellow w-36 h-36 rounded-lg"></div>
                    <div class="bg-green w-24 h-24 rounded-lg z-10"></div>
                </div>
            </div>

            <!-- Right Register Form Section -->
            <div class="w-1/2 p-8">
                <h2 class="mb-6 text-2xl font-bold text-yellow text-center">Register</h2>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <!-- Name -->
                    <div class="mb-4">
                        <label for="name" class="sr-only">Name</label>
                        <input type="text" name="name" id="name" required
                            class="w-full px-4 py-3 border rounded-lg focus:ring focus:outline-none focus:ring-yellow-500"
                            placeholder="Full Name">
                    </div>

                    <!-- Email -->
                    <div class="mb-4">
                        <label for="email" class="sr-only">Email</label>
                        <input type="email" name="email" id="email" required
                            class="w-full px-4 py-3 border rounded-lg focus:ring focus:outline-none focus:ring-yellow-500"
                            placeholder="Email Address">
                    </div>

                    <!-- Password -->
                    <div class="mb-4">
                        <label for="password" class="sr-only">Password</label>
                        <input type="password" name="password" id="password" required
                            class="w-full px-4 py-3 border rounded-lg focus:ring focus:outline-none focus:ring-yellow-500"
                            placeholder="Password">
                    </div>

                    <!-- Confirm Password -->
                    <div class="mb-4">
                        <label for="password_confirmation" class="sr-only">Confirm Password</label>
                        <input type="password" name="password_confirmation" id="password_confirmation" required
                            class="w-full px-4 py-3 border rounded-lg focus:ring focus:outline-none focus:ring-yellow-500"
                            placeholder="Confirm Password">
                    </div>

                    <!-- Submit Button -->
                    <button type="submit"
                        class="w-full py-3 font-bold text-white bg-yellow-500 rounded-lg hover:bg-yellow-600">
                        Register
                    </button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\panseat-scheduler\resources\views/auth/register.blade.php ENDPATH**/ ?>